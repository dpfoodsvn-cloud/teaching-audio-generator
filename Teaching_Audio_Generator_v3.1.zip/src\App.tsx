import { useState, useRef } from 'react';
import { TTSWorker } from './core/ttsWorker';
import { AudioStitcher } from './core/stitcher';
import JSZip from 'jszip';
import './App.css';

// Inline type definitions
interface ScriptLine {
    speaker: string;
    text: string;
}

interface ScriptSegment {
    id: string;
    section: string;
    name: string;
    duration?: string;
    speakerCount?: string;
    lines: ScriptLine[];
}

// Inline Script Parser - FIXED WITH ROBUST SEPARATOR DETECTION & IMPLICIT DIALOGUE START
class ScriptParser {
    static parse(content: string): ScriptSegment[] {
        console.log('Parser starting...');
        const segments: ScriptSegment[] = [];
        const lines = content.split(/\r?\n/);
        let currentSegment: ScriptSegment | null = null;
        let captureDialogue = false;
        let headersParsed = false;

        // Helper to detect separator lines (dashes, underscores, box drawing chars)
        const isSeparator = (line: string) => {
            // Must contain at least one separator char and consist ONLY of separator chars + whitespace
            // \u2010-\u2015: Unicode dashes/hyphens
            // \u2500-\u257F: Box drawing characters
            const separatorPattern = /^[\s\-\u2010-\u2015\u2500-\u257F_=]+$/;
            const hasSeparatorChar = /[\-\u2010-\u2015\u2500-\u257F_=]/;
            return separatorPattern.test(line) && hasSeparatorChar.test(line);
        };

        for (let i = 0; i < lines.length; i++) {
            const line = lines[i].trim();
            if (!line) continue;

            if (line.startsWith('SCRIPT ID:')) {
                if (currentSegment) segments.push(currentSegment);
                currentSegment = {
                    id: line.replace('SCRIPT ID:', '').trim(),
                    section: '',
                    name: '',
                    lines: []
                };
                captureDialogue = false;
                headersParsed = false;
                continue;
            }

            if (currentSegment) {
                if (line.startsWith('SECTION:')) {
                    currentSegment.section = line.replace('SECTION:', '').trim();
                } else if (line.startsWith('NAME:')) {
                    currentSegment.name = line.replace('NAME:', '').trim();
                } else if (line.startsWith('DURATION:')) {
                    currentSegment.duration = line.replace('DURATION:', '').trim();
                } else if (line.startsWith('SPEAKERS:')) {
                    currentSegment.speakerCount = line.replace('SPEAKERS:', '').trim();
                    headersParsed = true; // Usually the last header
                } else if (isSeparator(line)) {
                    captureDialogue = true;
                    console.log('Separator found for', currentSegment.id);
                } else {
                    // If we are not explicitly capturing dialogue yet, but we have parsed headers
                    // and this line is NOT a header, assume it's the start of dialogue (Implicit Separator)
                    if (!captureDialogue && headersParsed && !line.includes(':')) {
                        // Check if it really looks like dialogue (not a stray header)
                        // But for monologues, it might just be text.
                        // Let's assume if we passed headers, it's dialogue.
                        console.log('Implicit dialogue start for', currentSegment.id);
                        captureDialogue = true;
                    }

                    if (captureDialogue) {
                        // Skip section separators if found late
                        if (isSeparator(line)) continue;

                        // Check for "Speaker: Text" format
                        const match = line.match(/^([^:]+):\s*(.+)$/);
                        if (match) {
                            currentSegment.lines.push({
                                speaker: match[1].trim(),
                                text: match[2].trim()
                            });
                        } else {
                            // For narrator or single-speaker segments
                            let singleSpeaker: string | null = null;
                            if (currentSegment.speakerCount) {
                                const speakerMatch = currentSegment.speakerCount.match(/1\s*\(([^)]+)\)/);
                                if (speakerMatch) {
                                    singleSpeaker = speakerMatch[1].trim();
                                }
                            }

                            const speaker = singleSpeaker || 'Narrator';

                            // If line is not empty and not a separator, add it
                            if (line && !isSeparator(line)) {
                                if (currentSegment.lines.length > 0 && !singleSpeaker) {
                                    // Append to previous line if multi-speaker and no clear speaker
                                    currentSegment.lines[currentSegment.lines.length - 1].text += ' ' + line;
                                } else {
                                    // Create new line
                                    currentSegment.lines.push({ speaker, text: line });
                                }
                            }
                        }
                    }
                }
            }
        }
        if (currentSegment) segments.push(currentSegment);
        console.log('Parsed', segments.length, 'segments');
        return segments;
    }
}

function App() {
    // Essential state only
    const [apiKey, setApiKey] = useState(() => localStorage.getItem('gemini_api_key') || '');
    const [speed, setSpeed] = useState(1.0);
    const [retryDelay, setRetryDelay] = useState(1000);

    // Script upload state
    const [file, setFile] = useState<File | null>(null);
    const [fileName, setFileName] = useState<string>('');
    const [segments, setSegments] = useState<ScriptSegment[]>([]);
    const [speakers, setSpeakers] = useState<string[]>([]);
    const [voiceMapping, setVoiceMapping] = useState<Record<string, string>>({});
    const [isDragging, setIsDragging] = useState(false);

    // Processing state
    const [isProcessing, setIsProcessing] = useState(false);
    const [progress, setProgress] = useState(0);
    const [total, setTotal] = useState(0);
    const [status, setStatus] = useState('Ready to upload script template');

    const fileInputRef = useRef<HTMLInputElement>(null);
    const abortControllerRef = useRef<AbortController | null>(null);

    const voices = ['Zephyr', 'Puck', 'Charon', 'Kore', 'Fenrir', 'Aoede'];
    const MALE_VOICES = ['Zephyr', 'Puck', 'Charon', 'Fenrir'];
    const FEMALE_VOICES = ['Kore', 'Aoede'];

    // Simple heuristic for gender detection
    const detectGender = (name: string): 'male' | 'female' | 'unknown' => {
        const lowerName = name.toLowerCase();

        // Common female indicators
        const femalePatterns = [
            /\b(mrs|ms|miss|lady|woman|girl|mother|mom|mum|aunt|grandma|sister|daughter|queen|princess|sophie|sarah|mary|jane|lisa|emma|olivia|ava|isabella|mia|charlotte|amelia|harper|evelyn|anna|chloe)\b/,
            /^(she|her)$/
        ];

        // Common male indicators
        const malePatterns = [
            /\b(mr|sir|man|boy|father|dad|pop|uncle|grandpa|brother|son|king|prince|mark|john|james|robert|michael|william|david|richard|joseph|thomas|charles)\b/,
            /^(he|him)$/
        ];

        if (femalePatterns.some(p => p.test(lowerName))) return 'female';
        if (malePatterns.some(p => p.test(lowerName))) return 'male';

        return 'unknown';
    };

    // Save API key to localStorage
    const handleApiKeyChange = (value: string) => {
        setApiKey(value);
        localStorage.setItem('gemini_api_key', value);
    };

    const handleFileSelect = async (selectedFile: File) => {
        setFile(selectedFile);
        const nameWithoutExt = selectedFile.name.replace(/\.[^/.]+$/, "");
        setFileName(nameWithoutExt);

        const text = await selectedFile.text();
        const parsedSegments = ScriptParser.parse(text);
        setSegments(parsedSegments);
        setTotal(parsedSegments.length);

        const uniqueSpeakers = new Set<string>();
        parsedSegments.forEach(seg => {
            seg.lines.forEach(line => uniqueSpeakers.add(line.speaker));
        });
        const speakerList = Array.from(uniqueSpeakers);
        setSpeakers(speakerList);

        const initialMapping: Record<string, string> = {};

        // Track used voices to avoid repetition if possible
        let usedMaleVoices = 0;
        let usedFemaleVoices = 0;
        let usedNeutralVoices = 0;

        speakerList.forEach((speaker) => {
            const gender = detectGender(speaker);
            let assignedVoice = '';

            if (gender === 'female') {
                assignedVoice = FEMALE_VOICES[usedFemaleVoices % FEMALE_VOICES.length];
                usedFemaleVoices++;
            } else if (gender === 'male') {
                assignedVoice = MALE_VOICES[usedMaleVoices % MALE_VOICES.length];
                usedMaleVoices++;
            } else {
                // For unknown, alternate between available pools or just use main list
                assignedVoice = voices[usedNeutralVoices % voices.length];
                usedNeutralVoices++;
            }
            initialMapping[speaker] = assignedVoice;
        });

        setVoiceMapping(initialMapping);
        setStatus(`Loaded ${parsedSegments.length} segments with ${speakerList.length} speakers`);
    };

    const handleDragOver = (e: React.DragEvent) => {
        e.preventDefault();
        setIsDragging(true);
    };

    const handleDragLeave = (e: React.DragEvent) => {
        e.preventDefault();
        setIsDragging(false);
    };

    const handleDrop = (e: React.DragEvent) => {
        e.preventDefault();
        setIsDragging(false);
        if (e.dataTransfer.files?.[0]) {
            handleFileSelect(e.dataTransfer.files[0]);
        }
    };

    const handleVoiceChange = (speaker: string, voice: string) => {
        setVoiceMapping(prev => ({ ...prev, [speaker]: voice }));
    };

    const handleCancel = () => {
        if (abortControllerRef.current) {
            abortControllerRef.current.abort();
            abortControllerRef.current = null;
            setIsProcessing(false);
            setStatus('Cancelled by user');
        }
    };

    const handleGenerate = async () => {
        if (!apiKey.trim()) {
            alert('Please enter at least one API key');
            return;
        }

        if (segments.length === 0) {
            alert('Please upload a script template first');
            return;
        }

        // Parse API keys (split by newline or comma, trim whitespace, filter empty)
        const apiKeysList = apiKey.split(/[\n,]+/).map(k => k.trim()).filter(k => k.length > 0);

        if (apiKeysList.length === 0) {
            alert('Please enter a valid API key');
            return;
        }

        setIsProcessing(true);
        setProgress(0);
        setStatus('Starting audio generation...');
        abortControllerRef.current = new AbortController();

        const zip = new JSZip();
        let processedCount = 0;

        try {
            for (const segment of segments) {
                if (abortControllerRef.current?.signal.aborted) break;

                setStatus(`Processing segment ${segment.id} (${processedCount + 1}/${segments.length})...`);
                const lineBlobs: Blob[] = [];

                for (const line of segment.lines) {
                    const speakerVoice = voiceMapping[line.speaker] || voices[0];

                    // Generate complete line without splitting (optimized for teaching)
                    const results = await TTSWorker.generateBatch(
                        [line.text], // Complete line as single chunk
                        {
                            apiKey: apiKeysList[0], // Primary key (legacy support)
                            apiKeys: apiKeysList,   // List of keys for rotation
                            modelName: 'gemini-2.5-flash-preview-tts',
                            voiceName: speakerVoice,
                            stylePrompt: '',
                            temperature: 1,
                            speed,
                            pitch: 0,
                        },
                        1,
                        retryDelay, // User-controlled retry delay
                        undefined,
                        undefined,
                        abortControllerRef.current.signal
                    );

                    lineBlobs.push(results[0].audioBlob);
                }

                // Stitch all lines into segment audio
                const segmentAudio = await AudioStitcher.stitchAudio(lineBlobs);
                zip.file(`${segment.id}.wav`, segmentAudio);

                processedCount++;
                setProgress(processedCount);
            }

            if (processedCount > 0) {
                setStatus('Creating ZIP file...');
                const zipBlob = await zip.generateAsync({ type: 'blob' });
                const url = URL.createObjectURL(zipBlob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `${fileName || 'Teaching_Audio'}.zip`;
                a.click();
                setStatus(`Complete! Generated ${processedCount} audio files`);
            }
        } catch (error) {
            console.error('Generation error:', error);
            setStatus(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`);
            alert(`Generation failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
        } finally {
            setIsProcessing(false);
        }
    };

    return (
        <div className="app">
            <header className="app-header">
                <div className="container">
                    <h1 className="app-title">🎓 Teaching Audio Generator <span style={{ fontSize: '0.6em', opacity: 0.7 }}>v3.1</span></h1>
                    <p className="app-subtitle">Multi-Speaker Script to Audio</p>
                </div>
            </header>

            <main className="container">
                <div className="card">
                    {/* API Key & Speed Controls */}
                    <div className="controls-section">
                        <div className="control-group" style={{ flex: 2 }}>
                            <label htmlFor="api-key">API Keys * (One per line for rotation)</label>
                            <textarea
                                id="api-key"
                                value={apiKey}
                                onChange={(e) => handleApiKeyChange(e.target.value)}
                                placeholder="Enter your Gemini API keys (one per line)"
                                rows={3}
                                style={{
                                    width: '100%',
                                    padding: '8px',
                                    borderRadius: '4px',
                                    border: '1px solid #444',
                                    background: '#222',
                                    color: '#fff',
                                    fontFamily: 'monospace',
                                    resize: 'vertical'
                                }}
                            />
                        </div>
                        <div className="control-group" style={{ flex: 1 }}>
                            <label htmlFor="speed">Speed: {speed.toFixed(1)}x</label>
                            <input
                                id="speed"
                                type="range"
                                min="0.5"
                                max="2.0"
                                step="0.1"
                                value={speed}
                                onChange={(e) => setSpeed(Number(e.target.value))}
                            />
                        </div>
                        <div className="control-group" style={{ flex: 1 }}>
                            <label htmlFor="retry-delay">Retry Delay: {retryDelay}ms</label>
                            <input
                                id="retry-delay"
                                type="range"
                                min="1000"
                                max="10000"
                                step="500"
                                value={retryDelay}
                                onChange={(e) => setRetryDelay(Number(e.target.value))}
                            />
                        </div>
                    </div>

                    {/* Script Upload or Voice Mapping */}
                    {!file ? (
                        <div
                            className={`drop-zone ${isDragging ? 'dragging' : ''}`}
                            onDragOver={handleDragOver}
                            onDragLeave={handleDragLeave}
                            onDrop={handleDrop}
                            onClick={() => fileInputRef.current?.click()}
                        >
                            <input
                                type="file"
                                ref={fileInputRef}
                                onChange={(e) => e.target.files?.[0] && handleFileSelect(e.target.files[0])}
                                accept=".txt"
                                hidden
                            />
                            <div className="drop-zone-content">
                                <div className="upload-icon">📄</div>
                                <p>Drag & drop your script template here</p>
                                <p className="file-hint">or click to select a .txt file</p>
                            </div>
                        </div>
                    ) : (
                        <div className="mapping-section">
                            <div className="file-info">
                                <span>📄 {file.name}</span>
                                <button className="btn-secondary" onClick={() => setFile(null)}>Change File</button>
                            </div>

                            <div className="stats">
                                <div className="stat">
                                    <span className="stat-label">Segments</span>
                                    <span className="stat-value">{segments.length}</span>
                                </div>
                                <div className="stat">
                                    <span className="stat-label">Speakers</span>
                                    <span className="stat-value">{speakers.length}</span>
                                </div>
                            </div>

                            <div className="voice-mapping">
                                <h3>Voice Mapping</h3>
                                <p className="hint">Assign a voice to each speaker in your script</p>
                                <div className="mapping-grid">
                                    {speakers.map(speaker => (
                                        <div key={speaker} className="mapping-row">
                                            <span className="speaker-name">{speaker}</span>
                                            <select
                                                value={voiceMapping[speaker]}
                                                onChange={(e) => handleVoiceChange(speaker, e.target.value)}
                                            >
                                                {voices.map(v => (
                                                    <option key={v} value={v}>{v}</option>
                                                ))}
                                            </select>
                                        </div>
                                    ))}
                                </div>
                            </div>

                            <div className="action-buttons">
                                <button
                                    className="btn-primary"
                                    onClick={handleGenerate}
                                    disabled={isProcessing}
                                >
                                    🎙️ Generate Audio ({segments.length} segments)
                                </button>
                                {isProcessing && (
                                    <button className="btn-secondary" onClick={handleCancel}>
                                        ⏸ Cancel
                                    </button>
                                )}
                            </div>
                        </div>
                    )}

                    {/* Progress */}
                    {total > 0 && (
                        <div className="progress-section">
                            <div className="progress-info">
                                <span>{status}</span>
                                <span className="progress-count">{progress} / {total}</span>
                            </div>
                            <div className="progress-bar">
                                <div
                                    className="progress-fill"
                                    style={{ width: `${(progress / total) * 100}%` }}
                                />
                            </div>
                        </div>
                    )}
                </div>
            </main>
        </div>
    );
}

export default App;
