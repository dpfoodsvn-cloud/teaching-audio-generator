import { useState, useRef, useEffect } from 'react';
import { SettingsPanel } from './components/SettingsPanel';
import { MainPanel } from './components/MainPanel';
import type { FavoritePreset } from './components/FavoritesPanel';
import { SavePresetModal } from './components/SavePresetModal';
import type { BatchFile } from './components/BatchProcessor';
import { AudioConverter } from './core/audioConverter';
import { TextSplitter } from './core/splitter';
import { SSMLHelper } from './core/ssmlHelper';
import { TextPreprocessor } from './core/textPreprocessor';
import { AmbianceMixer } from './core/ambianceMixer';
import { TTSWorker } from './core/ttsWorker';
import { AudioStitcher } from './core/stitcher';
import JSZip from 'jszip';
import './App.css';

function App() {
  // Tab state
  const [activeTab, setActiveTab] = useState<'execute' | 'settings'>('execute');

  // Settings state
  const [apiKey, setApiKey] = useState(() => localStorage.getItem('gemini_api_key') || '');
  const [apiKeys, setApiKeys] = useState(() => localStorage.getItem('gemini_api_keys') || ''); // Additional API keys for rotation
  const [model, setModel] = useState('gemini-2.5-flash-preview-tts');
  const [voice, setVoice] = useState('Zephyr');
  const [stylePrompt, setStylePrompt] = useState('');
  const [temperature, setTemperature] = useState(1);
  const [speed, setSpeed] = useState(1);
  const [pitch, setPitch] = useState(0);

  // Favorites state
  const [favorites, setFavorites] = useState<FavoritePreset[]>(() => {
    const saved = localStorage.getItem('gemini_tts_favorites');
    return saved ? JSON.parse(saved) : [];
  });

  // Persistence effects
  useEffect(() => {
    localStorage.setItem('gemini_api_key', apiKey);
  }, [apiKey]);

  useEffect(() => {
    localStorage.setItem('gemini_api_keys', apiKeys);
  }, [apiKeys]);

  useEffect(() => {
    localStorage.setItem('gemini_tts_favorites', JSON.stringify(favorites));
  }, [favorites]);

  // Main panel state
  const [text, setText] = useState('');
  const [splitSize, setSplitSize] = useState(600);
  const [concurrency, setConcurrency] = useState(1);
  const [delay, setDelay] = useState(5000);

  // Generation state
  const [isGenerating, setIsGenerating] = useState(false);
  const [progress, setProgress] = useState(0);
  const [total, setTotal] = useState(0);
  const [status, setStatus] = useState('No tasks yet.');
  const [downloadUrl, setDownloadUrl] = useState<string | null>(null);
  const [downloadFilename, setDownloadFilename] = useState<string>('');
  const [notification, setNotification] = useState<string | null>(null);
  const [audioFormat, setAudioFormat] = useState<'wav' | 'mp3'>('wav');
  const [enableSSML, setEnableSSML] = useState(false);
  const [enablePreprocessing, setEnablePreprocessing] = useState(true);

  // Batch processing state
  const [batchMode, setBatchMode] = useState(false);
  const [batchFiles, setBatchFiles] = useState<BatchFile[]>([]);
  const [isBatchProcessing, setIsBatchProcessing] = useState(false);
  const [batchPaused, setBatchPaused] = useState(false);
  const [currentBatchIndex, setCurrentBatchIndex] = useState(0);

  // Ambiance state
  const [ambianceEnabled, setAmbianceEnabled] = useState(false);
  const [ambianceType, setAmbianceType] = useState('none');
  const [ambianceVolume, setAmbianceVolume] = useState(30);

  // Project management state
  interface Project {
    id: string;
    name: string;
    created: string;
    text: string;
    settings: {
      voice: string;
      temperature: number;
      speed: number;
      pitch: number;
      stylePrompt: string;
      splitSize: number;
      concurrency: number;
      delay: number;
    };
  }

  const [projects, setProjects] = useState<Project[]>(() => {
    const saved = localStorage.getItem('gemini_tts_projects');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('gemini_tts_projects', JSON.stringify(projects));
  }, [projects]);

  // Modal state
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentSlotId, setCurrentSlotId] = useState<number | null>(null);

  const showNotification = (message: string) => {
    setNotification(message);
    setTimeout(() => setNotification(null), 3000);
  };

  // Abort controller for cancellation
  const abortControllerRef = useRef<AbortController | null>(null);

  const handleCancel = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
      setIsGenerating(false);
      setStatus('Cancelled by user.');
    }
  };

  const handleGenerate = async () => {
    if (!apiKey.trim()) {
      alert('Please enter your API key in the Settings tab');
      setActiveTab('settings');
      return;
    }

    if (!text.trim()) {
      alert('Please enter text to generate audio');
      return;
    }

    // Create new abort controller
    abortControllerRef.current = new AbortController();

    setIsGenerating(true);
    setProgress(0);
    setDownloadUrl(null); // Reset download URL
    setStatus('Preparing text...');

    try {
      // Preprocess text if enabled
      let processedText = text;
      if (enablePreprocessing) {
        setStatus('Preprocessing text...');
        processedText = TextPreprocessor.preprocess(text);
        console.log('[App] Text preprocessed');
      }

      // Wrap with SSML if enabled and not already wrapped
      if (enableSSML && !SSMLHelper.hasSSML(processedText)) {
        processedText = SSMLHelper.wrapSpeak(processedText);
        console.log('[App] Text wrapped with SSML');
      }

      // Split text
      setStatus('Splitting text...');
      const chunks = TextSplitter.splitText(processedText, splitSize);
      setTotal(chunks.length);
      setStatus(`Processing ${chunks.length} chunks...`);

      // Parse additional API keys
      const additionalKeys = apiKeys
        .split('\n')
        .map(k => k.trim())
        .filter(k => k.length > 0);

      // Generate audio
      const results = await TTSWorker.generateBatch(
        chunks,
        {
          apiKey,
          apiKeys: additionalKeys,
          modelName: model,
          voiceName: voice,
          stylePrompt,
          temperature,
          speed,
          pitch,
        },
        concurrency,
        delay,
        (completed, total) => {
          setProgress(completed);
          setStatus(`Generating audio: ${completed}/${total}`);
        },
        (message) => {
          setStatus(message);
        },
        abortControllerRef.current.signal // Pass signal
      );

      setStatus('Stitching audio...');

      // Stitch audio
      const audioBlobs = results.map((r) => r.audioBlob);
      const finalAudio = await AudioStitcher.stitchAudio(audioBlobs);

      // Create download with structured filename
      // Format: TTS_[Voice]_[TextSnippet]_[Date].wav
      const dateStr = new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-');
      const textSnippet = text.slice(0, 30).replace(/[^a-z0-9]/gi, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');
      const safeVoice = voice.replace(/[^a-z0-9]/gi, '');
      const filename = `TTS_${safeVoice}_${textSnippet}_${dateStr}.wav`;

      console.log(`[App] Starting download for ${filename} (${finalAudio.size} bytes, type: ${finalAudio.type})`);
      setDownloadFilename(filename);

      // Auto-trigger download/save
      await handleSave(finalAudio, filename);

      setStatus(`Complete! Ready to save.`);
    } catch (error) {
      console.error('Generation error:', error);
      setStatus(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`);
      alert(`Audio generation failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSave = async (blob: Blob, filename: string) => {
    let finalBlob = blob;
    let finalFilename = filename;

    // Mix with ambiance if enabled
    if (ambianceEnabled && ambianceType !== 'none') {
      setStatus(`Mixing with ${ambianceType} ambiance...`);
      try {
        finalBlob = await AmbianceMixer.mixAudio(blob, ambianceType, ambianceVolume);
        console.log('[App] Mixed with ambiance');
      } catch (error) {
        console.error('[App] Ambiance mixing failed:', error);
        showNotification('Ambiance mixing failed, continuing without it');
        // Fall back to original audio
      }
    }

    // Convert to MP3 if selected
    if (audioFormat === 'mp3') {
      setStatus('Converting to MP3...');
      try {
        finalBlob = await AudioConverter.wavToMp3(finalBlob);
        finalFilename = filename.replace('.wav', '.mp3');
        console.log('[App] Converted to MP3');
      } catch (error) {
        console.error('[App] MP3 conversion failed:', error);
        showNotification('MP3 conversion failed, downloading as WAV');
        // Fall back to WAV
      }
    }

    try {
      // @ts-ignore - showSaveFilePicker is not yet in standard types
      if (window.showSaveFilePicker) {
        // @ts-ignore
        const handle = await window.showSaveFilePicker({
          suggestedName: finalFilename,
          types: [{
            description: audioFormat === 'mp3' ? 'MP3 Audio File' : 'WAV Audio File',
            accept: audioFormat === 'mp3' ? { 'audio/mp3': ['.mp3'] } : { 'audio/wav': ['.wav'] },
          }],
        });
        const writable = await handle.createWritable();
        await writable.write(finalBlob);
        await writable.close();
        console.log('[App] Saved via File System Access API');
        return;
      }
    } catch (err) {
      console.warn('[App] File System Access API failed or cancelled, falling back to download:', err);
    }

    // Fallback to classic download
    // Force application/octet-stream to prevent browser from playing it
    const downloadBlob = new Blob([finalBlob], { type: 'application/octet-stream' });
    const url = URL.createObjectURL(downloadBlob);
    setDownloadUrl(url);
    setDownloadFilename(finalFilename);

    const a = document.createElement('a');
    a.style.display = 'none';
    a.href = url;
    a.download = finalFilename;
    document.body.appendChild(a);
    a.click();
    console.log('[App] Triggered download');

    // No cleanup to ensure reliability
  };

  const handleSaveRequest = (slotId: number) => {
    setCurrentSlotId(slotId);
    setIsModalOpen(true);
  };

  const handleModalSave = (name: string) => {
    if (currentSlotId === null) return;

    const newPreset: FavoritePreset = {
      id: currentSlotId,
      name,
      voice,
      stylePrompt,
      temperature,
      speed,
      pitch,
    };
    setFavorites(prev => {
      const filtered = prev.filter(f => f.id !== currentSlotId);
      const updated = [...filtered, newPreset].sort((a, b) => a.id - b.id);
      return updated;
    });

    showNotification(`Saved preset "${name}" to slot #${currentSlotId}!`);
    setIsModalOpen(false);
    setCurrentSlotId(null);
  };

  const handleLoadFavorite = (preset: FavoritePreset) => {
    setVoice(preset.voice);
    setStylePrompt(preset.stylePrompt);
    setTemperature(preset.temperature);
    setSpeed(preset.speed);
    setPitch(preset.pitch);
  };

  const handleDeleteFavorite = (slotId: number) => {
    setFavorites(prev => prev.filter(f => f.id !== slotId));
  };

  // Project Management Functions
  const handleSaveProject = (projectName: string) => {
    const newProject: Project = {
      id: Date.now().toString(),
      name: projectName,
      created: new Date().toISOString(),
      text,
      settings: {
        voice,
        temperature,
        speed,
        pitch,
        stylePrompt,
        splitSize,
        concurrency,
        delay,
      },
    };
    setProjects(prev => [...prev, newProject]);
    showNotification(`Project "${projectName}" saved!`);
  };

  const handleLoadProject = (project: Project) => {
    setText(project.text);
    setVoice(project.settings.voice);
    setTemperature(project.settings.temperature);
    setSpeed(project.settings.speed);
    setPitch(project.settings.pitch);
    setStylePrompt(project.settings.stylePrompt);
    setSplitSize(project.settings.splitSize);
    setConcurrency(project.settings.concurrency);
    setDelay(project.settings.delay);
    showNotification(`Project "${project.name}" loaded!`);
  };

  const handleDeleteProject = (projectId: string) => {
    setProjects(prev => prev.filter(p => p.id !== projectId));
    showNotification('Project deleted');
  };

  const handleExportProjects = () => {
    const dataStr = JSON.stringify(projects, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `tts_projects_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    showNotification('Projects exported!');
  };

  const handleImportProjects = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const imported = JSON.parse(e.target?.result as string);
        setProjects(prev => [...prev, ...imported]);
        showNotification(`Imported ${imported.length} project(s)!`);
      } catch (error) {
        showNotification('Import failed: Invalid file format');
      }
    };
    reader.readAsText(file);
  };

  // Batch Processing Functions
  const handleBatchFilesAdd = (files: File[]) => {
    const newFiles: BatchFile[] = files.slice(0, 10 - batchFiles.length).map(file => ({
      id: Date.now().toString() + Math.random(),
      name: file.name,
      content: '',
      status: 'pending',
      progress: 0,
    }));

    // Read file contents
    newFiles.forEach(batchFile => {
      const file = files.find(f => f.name === batchFile.name);
      if (file) {
        const reader = new FileReader();
        reader.onload = (e) => {
          setBatchFiles(prev => prev.map(f =>
            f.id === batchFile.id ? { ...f, content: e.target?.result as string } : f
          ));
        };
        reader.readAsText(file);
      }
    });

    setBatchFiles(prev => [...prev, ...newFiles]);
  };

  const handleBatchFileRemove = (id: string) => {
    setBatchFiles(prev => prev.filter(f => f.id !== id));
  };

  const handleBatchProcess = async () => {
    setIsBatchProcessing(true);
    setBatchPaused(false);
    setCurrentBatchIndex(0);

    for (let i = 0; i < batchFiles.length; i++) {
      if (batchPaused) {
        console.log('[Batch] Paused at index', i);
        setCurrentBatchIndex(i);
        return;
      }

      const file = batchFiles[i];
      if (file.status === 'complete') continue;

      try {
        // Update status
        setBatchFiles(prev => prev.map((f, idx) =>
          idx === i ? { ...f, status: 'processing', progress: 0 } : f
        ));

        // Process this file's text
        let processedText = file.content;
        if (enablePreprocessing) {
          processedText = TextPreprocessor.preprocess(processedText);
        }
        if (enableSSML && !SSMLHelper.hasSSML(processedText)) {
          processedText = SSMLHelper.wrapSpeak(processedText);
        }

        const chunks = TextSplitter.splitText(processedText, splitSize);
        const additionalKeys = apiKeys.split(',').map(k => k.trim()).filter(k => k);

        const config = {
          apiKey,
          apiKeys: additionalKeys,
          modelName: model,
          voiceName: voice,
          stylePrompt,
          temperature,
          speed,
          pitch,
        };

        const results = await TTSWorker.generateBatch(
          chunks,
          config,
          concurrency,
          delay,
          (current: number, total: number) => {
            const progress = Math.round((current / total) * 100);
            setBatchFiles(prev => prev.map((f, idx) =>
              idx === i ? { ...f, progress } : f
            ));
          },
          undefined, // onStatusUpdate
          abortControllerRef.current?.signal
        );

        const audioBlobs = results.map(r => r.audioBlob);
        let finalAudio = await AudioStitcher.stitchAudio(audioBlobs);

        // Apply ambiance if enabled
        if (ambianceEnabled && ambianceType !== 'none') {
          try {
            finalAudio = await AmbianceMixer.mixAudio(finalAudio, ambianceType, ambianceVolume);
          } catch (error) {
            console.error('[Batch] Ambiance mixing failed:', error);
          }
        }

        // Convert to MP3 if needed
        if (audioFormat === 'mp3') {
          try {
            finalAudio = await AudioConverter.wavToMp3(finalAudio);
          } catch (error) {
            console.error('[Batch] MP3 conversion failed:', error);
          }
        }

        // Mark complete
        setBatchFiles(prev => prev.map((f, idx) =>
          idx === i ? { ...f, status: 'complete', progress: 100, audioBlob: finalAudio } : f
        ));

        // Delay before next file
        if (i < batchFiles.length - 1) {
          await new Promise(resolve => setTimeout(resolve, 5000));
        }
      } catch (error) {
        console.error('[Batch] File processing failed:', error);
        setBatchFiles(prev => prev.map((f, idx) =>
          idx === i ? { ...f, status: 'failed', error: error instanceof Error ? error.message : 'Unknown error' } : f
        ));
      }
    }

    setIsBatchProcessing(false);
    showNotification('Batch processing complete!');
  };

  const handleBatchPause = () => {
    setBatchPaused(!batchPaused);
  };

  const handleBatchCancel = () => {
    setIsBatchProcessing(false);
    setBatchPaused(false);
    setBatchFiles(prev => prev.map(f =>
      f.status === 'processing' ? { ...f, status: 'pending', progress: 0 } : f
    ));
  };

  const handleBatchDownload = async () => {
    const completedFiles = batchFiles.filter(f => f.status === 'complete' && f.audioBlob);
    if (completedFiles.length === 0) return;

    const zip = new JSZip();
    const ext = audioFormat === 'mp3' ? '.mp3' : '.wav';

    completedFiles.forEach((file, index) => {
      const filename = file.name.replace('.txt', ext);
      zip.file(filename, file.audioBlob!);
    });

    const zipBlob = await zip.generateAsync({ type: 'blob' });
    const url = URL.createObjectURL(zipBlob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `TTS_Batch_${new Date().toISOString().slice(0, 10)}.zip`;
    a.click();
    showNotification(`Downloaded ${completedFiles.length} files!`);
  };

  return (
    <div className="app">
      <header className="app-header">
        <div className="container">
          <h1 className="app-title">PhilNguyen Voice System</h1>
          <p className="app-subtitle">Fusion + Threads + Settings</p>
        </div>
      </header>

      <main className="container">
        <div className="tabs">
          <button
            className={`tab ${activeTab === 'execute' ? 'active' : ''}`}
            onClick={() => setActiveTab('execute')}
          >
            Execute
          </button>
          <button
            className={`tab ${activeTab === 'settings' ? 'active' : ''}`}
            onClick={() => setActiveTab('settings')}
          >
            Settings
          </button>
        </div>

        <div className="tab-content card">
          {activeTab === 'execute' ? (
            <MainPanel
              text={text}
              setText={setText}
              splitSize={splitSize}
              setSplitSize={setSplitSize}
              concurrency={concurrency}
              setConcurrency={setConcurrency}
              delay={delay}
              setDelay={setDelay}
              onGenerate={handleGenerate}
              onCancel={handleCancel}
              isGenerating={isGenerating}
              progress={progress}
              total={total}
              status={status}
              downloadUrl={downloadUrl}
              downloadFilename={downloadFilename}
              audioFormat={audioFormat}
              setAudioFormat={setAudioFormat}
              projects={projects}
              onSaveProject={handleSaveProject}
              onLoadProject={handleLoadProject}
              onDeleteProject={handleDeleteProject}
              onExportProjects={handleExportProjects}
              onImportProjects={handleImportProjects}
              enableSSML={enableSSML}
              setEnableSSML={setEnableSSML}
              enablePreprocessing={enablePreprocessing}
              setEnablePreprocessing={setEnablePreprocessing}
              batchMode={batchMode}
              setBatchMode={setBatchMode}
              batchFiles={batchFiles}
              onBatchFilesAdd={handleBatchFilesAdd}
              onBatchFileRemove={handleBatchFileRemove}
              onBatchProcess={handleBatchProcess}
              onBatchPause={handleBatchPause}
              onBatchCancel={handleBatchCancel}
              onBatchDownload={handleBatchDownload}
              isBatchProcessing={isBatchProcessing}
              batchPaused={batchPaused}
            />
          ) : (
            <SettingsPanel
              apiKey={apiKey}
              setApiKey={setApiKey}
              apiKeys={apiKeys}
              setApiKeys={setApiKeys}
              model={model}
              setModel={setModel}
              voice={voice}
              setVoice={setVoice}
              stylePrompt={stylePrompt}
              setStylePrompt={setStylePrompt}
              temperature={temperature}
              setTemperature={setTemperature}
              speed={speed}
              setSpeed={setSpeed}
              pitch={pitch}
              setPitch={setPitch}
              concurrency={concurrency}
              setConcurrency={setConcurrency}
              delay={delay}
              setDelay={setDelay}
              favorites={favorites}
              onSaveFavorite={handleSaveRequest}
              onLoadFavorite={handleLoadFavorite}
              onDeleteFavorite={handleDeleteFavorite}
              ambianceEnabled={ambianceEnabled}
              setAmbianceEnabled={setAmbianceEnabled}
              ambianceType={ambianceType}
              setAmbianceType={setAmbianceType}
              ambianceVolume={ambianceVolume}
              setAmbianceVolume={setAmbianceVolume}
            />
          )}
        </div>
      </main>

      <SavePresetModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSave={handleModalSave}
        initialName={`Preset ${currentSlotId || ''}`}
      />

      {notification && (
        <div className="notification-toast">
          {notification}
        </div>
      )}
    </div>
  );
}

export default App;
